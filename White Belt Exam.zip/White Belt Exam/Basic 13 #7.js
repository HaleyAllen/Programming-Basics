
function thatsOdd(){
    var strangeActivity =[]
    for(var i = 0; i <= 255; i++){
        if(i % 2 !== 0){
            strangeActivity.push(i)
        }
    }
    return strangeActivity
}
console.log(thatsOdd())