

function noNegativesHere(arr){
    for(var i = 0; i < arr.length; i++){
        if(arr[i] < 0){
            arr[i] = "dojo"
        }
    }
    return arr
}
console.log(noNegativesHere([1,2,3,-4,5]))