

function betterThenY(arr,y){
    for(var i = 0; i < arr.length; i++){
        if( arr[i] > y ){
            console.log(arr[i])
        }
    }
}
betterThenY([1,2,3,4,5,6,7,8,9],3)