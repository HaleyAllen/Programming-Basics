

function moveOver(arr){
    arr.shift()
    arr.push(0)
    return arr
}
console.log(moveOver([1,2,3,4,5]))