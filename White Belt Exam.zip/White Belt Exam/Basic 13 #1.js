

function print1To255(){
    for(var i = 1; i < 256; i = i + 1){
        console.log(i)
    }
}
print1To255()