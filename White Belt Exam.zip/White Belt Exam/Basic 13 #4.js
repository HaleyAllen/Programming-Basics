
function printArrayVals(arr){
    for(var i = 0; i < arr.length; i = i + 1){
        console.log(arr[i])
    }
}
printArrayVals([1,2,3,4,5])