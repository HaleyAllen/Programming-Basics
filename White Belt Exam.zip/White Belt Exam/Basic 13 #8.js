
function squaredUp(arr){
    for(var i = 0; i < arr.length; i++) {
        arr[i] = Math.sqrt(arr[i])
    }
    return arr
}
console.log(squaredUp([1,2,3,4,5]))




