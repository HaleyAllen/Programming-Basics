
function oddOnesOut(){
    for(var i = 1; i < 255; i = i + 1){
        if(i % 2 !== 0){
            console.log(i)
        }
    }
}
oddOnesOut()