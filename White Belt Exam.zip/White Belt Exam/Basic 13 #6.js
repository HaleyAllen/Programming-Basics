
var average = 0

function findTheAverage(arr){
    for(var i = 0; i<arr.length; i++){
        average = average + arr[i]
    }
    average = average / arr.length
    return average
}
console.log(findTheAverage([1,2,3,4,5]))