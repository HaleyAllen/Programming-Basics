

function tooPositive(arr){
    for(var i = 0; i < arr.length; i++){
        if(arr[i] < 0){
            arr[i] = 0
        }
    }
    return arr
}
console.log(tooPositive([-1,2,4,7,-18,-3]))