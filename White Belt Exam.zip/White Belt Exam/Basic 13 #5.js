
function findTheLargest(arr){
    var largest = -Infinity
    for(var i = 0; i < arr.length; i++){
        if( arr[i] > largest ){
            largest = arr[i]
        }
    } return largest
}
console.log(findTheLargest([-1,3,5,-12,22]))