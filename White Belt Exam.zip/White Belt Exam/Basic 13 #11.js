
function mathWizz(arr){
    var lowest = +Infinity
    var highest = -Infinity
    var average = 0
    for(var i = 0; i < arr.length; i++){
        average = average + arr[i]
        if(arr[i] < lowest){
            lowest = arr[i]
        } else if (arr[i]> highest){
            highest = arr[i]
        }
    }
    average = average / arr.length
    console.log(average,lowest,highest)
}
mathWizz([1,2,3,4,5])
